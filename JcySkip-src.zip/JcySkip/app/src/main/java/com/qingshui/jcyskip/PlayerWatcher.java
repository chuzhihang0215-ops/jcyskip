package com.qingshui.jcyskip;

import android.os.Handler;
import android.os.Looper;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.XposedHelpers;

/**
 * 单个播放器实例的看守：每 0.7 秒读一次播放进度，命中规则就 seek。
 *
 * 进度/时长用的是阿里云播放器 Java API 的 getCurrentPosition()/getDuration()，
 * 底层分别是 libsaasCorePlayer.so 里的 java_GetCurrentPosition / java_GetDuration。
 */
final class PlayerWatcher {

    private static final Map<Object, PlayerWatcher> POOL =
            new WeakHashMap<Object, PlayerWatcher>();

    /** 防止自己发起的 seek 被学习逻辑当成用户拖动 */
    private static final ThreadLocal<Boolean> SELF_SEEK = new ThreadLocal<Boolean>();

    static boolean isSelfSeek() {
        return Boolean.TRUE.equals(SELF_SEEK.get());
    }

    private final Object player;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            doTick();
        }
    };

    private boolean doneIntro;
    private boolean doneOutro;
    private long lastPos = -1L;
    private String key = "";

    private PlayerWatcher(Object player) {
        this.player = player;
    }

    static synchronized void attach(Object player) {
        if (player == null || POOL.containsKey(player)) return;
        PlayerWatcher w = new PlayerWatcher(player);
        POOL.put(player, w);
        MainHook.log("player instance = " + player.getClass().getName());
        w.handler.postDelayed(w.tick, 1500);
    }

    static synchronized void onSourceChanged(Object player, String rawUri) {
        PlayerWatcher w = POOL.get(player);
        if (w == null) return;
        w.doneIntro = false;
        w.doneOutro = false;
        w.lastPos = -1L;
        w.key = SkipStore.keyOf(rawUri);
        MainHook.log("source changed -> key=" + w.key + " uri=" + rawUri);
    }

    static void onUserSeek(Object player, long targetMs) {
        PlayerWatcher w;
        synchronized (PlayerWatcher.class) {
            w = POOL.get(player);
            if (w == null) PlayerWatcher.attach(player);
            w = POOL.get(player);
        }
        if (w == null) return;
        long cur = w.callLong("getCurrentPosition", -1L);
        if (cur < 0) return;
        SkipStore.learn(w.key, cur, targetMs);
    }

    // ------------------------------------------------------------------ 主循环
    private void doTick() {
        try {
            SkipStore.reload();
            if (!SkipStore.enabled()) {
                schedule(2000);
                return;
            }
            long dur = callLong("getDuration", 0L);
            long pos = callLong("getCurrentPosition", -1L);
            if (dur <= 0 || pos < 0) {
                schedule(1500);
                return;
            }

            // 用户往回拖了 3 秒以上 -> 允许重新判定
            if (lastPos >= 0 && pos < lastPos - 3000) {
                doneIntro = false;
                doneOutro = false;
            }
            lastPos = pos;

            long intro = SkipStore.introMs(key);
            long outro = SkipStore.outroMs(key);

            if (!doneIntro && intro > 0 && intro < dur - 5000
                    && pos >= intro - 800 && pos <= intro + 3000) {
                seekTo(intro + 200);
                doneIntro = true;
                MainHook.log("跳过片头: " + pos + "ms -> " + (intro + 200) + "ms");
            } else if (!doneOutro && outro > 0
                    && dur - pos <= outro && dur - pos > 800) {
                // 跳到结尾触发 onCompletion，多数播放器随后会自动播下一集
                seekTo(dur - 300);
                doneOutro = true;
                MainHook.log("跳过片尾: 剩余 " + (dur - pos) + "ms -> 跳到结尾");
            }
            schedule(700);
        } catch (Throwable t) {
            MainHook.log("tick error: " + t);
            schedule(2000);
        }
    }

    private void schedule(long ms) {
        handler.removeCallbacks(tick);
        handler.postDelayed(tick, ms);
    }

    // ------------------------------------------------------------- 反射调用
    private long callLong(String name, long def) {
        try {
            Object r = XposedHelpers.callMethod(player, name);
            if (r instanceof Long) return ((Long) r).longValue();
            if (r instanceof Integer) return ((Integer) r).longValue();
        } catch (Throwable ignore) {
        }
        return def;
    }

    private void seekTo(long ms) {
        SELF_SEEK.set(Boolean.TRUE);
        try {
            for (Class<?> c = player.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                for (Method m : c.getDeclaredMethods()) {
                    if (!"seekTo".equals(m.getName())) continue;
                    Class<?>[] pt = m.getParameterTypes();
                    try {
                        if (pt.length == 1 && pt[0] == long.class) {
                            m.setAccessible(true);
                            m.invoke(player, Long.valueOf(ms));
                            return;
                        }
                        if (pt.length == 2 && pt[0] == long.class) {
                            Object mode = pickSeekMode(pt[1]);
                            if (mode == null) continue;
                            m.setAccessible(true);
                            m.invoke(player, Long.valueOf(ms), mode);
                            return;
                        }
                    } catch (Throwable ignore) {
                    }
                }
            }
            XposedHelpers.callMethod(player, "seekTo", Long.valueOf(ms));
        } catch (Throwable t) {
            MainHook.log("seekTo 失败: " + t);
        } finally {
            SELF_SEEK.set(Boolean.FALSE);
        }
    }

    private static Object pickSeekMode(Class<?> type) {
        if (!type.isEnum()) return null;
        Object[] cs = type.getEnumConstants();
        if (cs == null || cs.length == 0) return null;
        for (Object o : cs) {
            if ("Accurate".equalsIgnoreCase(String.valueOf(o))) return o;
        }
        for (Object o : cs) {
            if (String.valueOf(o).toLowerCase().contains("accurate")) return o;
        }
        return cs[0];
    }
}
