package com.qingshui.jcyskip;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/**
 * 配置与规则存储。
 *
 * 故意不写设置界面：模块的 SharedPreferences 和被注入的 App 不是同一个包，
 * 跨进程读 prefs 在 Android 6+ 上是坑。改成放在 App 自己的外部私有目录里的
 * 纯文本文件，文件管理器能直接编辑，播放中改完 1 秒内生效。
 *
 * 路径：/sdcard/Android/data/com.tudou.tool/files/jcy_skip.txt
 *
 * 内容（单位全部是「秒」）：
 *   enabled=1        1 开启 / 0 关闭
 *   intro=92         片头结束位置，播放到 92 秒就跳到 92.2 秒
 *   outro=90         片尾提前 90 秒跳到结尾（0 = 关闭片尾跳过）
 *   auto_learn=1     是否自动学习用户手动拖过的位置
 *   intro.<key>=92   按剧单独覆盖（key 会打在日志里）
 */
final class SkipStore {

    private static final String FILE_NAME = "jcy_skip.txt";

    private static File config;
    private static long lastMod = -2L;

    private static boolean enabled = true;
    private static boolean autoLearn = true;
    private static long introMs = 0L;
    private static long outroMs = 0L;

    private static final Properties PER_KEY = new Properties();

    /** 学习确认：连续两次落在同一位置 ±10 秒才算数 */
    private static long pendingTo = -1L;

    private SkipStore() {
    }

    // ------------------------------------------------------------------ 初始化
    static void init(Context ctx) {
        File dir = ctx.getExternalFilesDir(null);
        if (dir == null) dir = ctx.getFilesDir();
        config = new File(dir, FILE_NAME);
        MainHook.log("配置文件: " + config.getAbsolutePath());
        if (!config.exists()) writeDefault();
        lastMod = -2L;
        reload();
    }

    private static void writeDefault() {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(config);
            out.write(("# 囧次元自动跳过片头/片尾，单位: 秒。改完保存后 1 秒内生效\n"
                    + "enabled=1\n"
                    + "intro=0\n"
                    + "outro=0\n"
                    + "auto_learn=1\n").getBytes("UTF-8"));
            out.flush();
        } catch (Throwable t) {
            MainHook.log("写默认配置失败: " + t);
        } finally {
            try {
                if (out != null) out.close();
            } catch (Throwable ignore) {
            }
        }
    }

    // ------------------------------------------------------------------ 读取
    static synchronized void reload() {
        if (config == null) return;
        long m = config.exists() ? config.lastModified() : 0L;
        if (m == lastMod) return;
        lastMod = m;

        Properties p = new Properties();
        FileInputStream in = null;
        try {
            in = new FileInputStream(config);
            p.load(in);
        } catch (Throwable t) {
            MainHook.log("读配置失败: " + t);
        } finally {
            try {
                if (in != null) in.close();
            } catch (Throwable ignore) {
            }
        }

        enabled = !"0".equals(p.getProperty("enabled", "1").trim());
        autoLearn = !"0".equals(p.getProperty("auto_learn", "1").trim());
        introMs = secToMs(p.getProperty("intro", "0"));
        outroMs = secToMs(p.getProperty("outro", "0"));

        PER_KEY.clear();
        for (String name : p.stringPropertyNames()) {
            if (name.startsWith("intro.")) {
                PER_KEY.setProperty(name.substring(6).trim(), p.getProperty(name, "0"));
            }
        }
        MainHook.log("配置已加载 enabled=" + enabled + " intro=" + introMs
                + "ms outro=" + outroMs + "ms learn=" + autoLearn
                + " 按剧规则=" + PER_KEY.size());
    }

    static boolean enabled() {
        return enabled;
    }

    static long introMs(String key) {
        String v = key == null || key.isEmpty() ? null : PER_KEY.getProperty(key);
        if (v != null) return secToMs(v);
        return introMs;
    }

    static long outroMs(String key) {
        // 片尾只用全局值（每集的片尾长度差异不大）
        return outroMs;
    }

    private static long secToMs(String s) {
        if (s == null) return 0L;
        try {
            double v = Double.parseDouble(s.trim());
            if (v <= 0) return 0L;
            return (long) (v * 1000.0);
        } catch (Throwable t) {
            return 0L;
        }
    }

    // ------------------------------------------------------------------ 学习
    /**
     * 用户手动 seek 时被调用。
     * 只在「前 5 分钟内、往前跳了 15 秒以上」时当作跳过片头，
     * 并要求连续两次跳到的位置相差 10 秒以内才落盘，避免误学。
     */
    static synchronized void learn(String key, long fromMs, long toMs) {
        if (!enabled || !autoLearn) return;
        if (fromMs < 0 || toMs <= 0) return;
        if (fromMs > 300000L) return;            // 超过 5 分钟的不当片头
        if (toMs - fromMs < 15000L) return;      // 至少跳 15 秒
        if (toMs > 1800000L) return;             // 超过 30 分钟不合理

        if (pendingTo > 0 && Math.abs(toMs - pendingTo) <= 10000L) {
            commit(key, toMs);
            pendingTo = -1L;
        } else {
            pendingTo = toMs;
            MainHook.log("学习候选: 从 " + fromMs + "ms 跳到 " + toMs + "ms（再跳一次同样位置即生效）");
        }
    }

    private static void commit(String key, long toMs) {
        Properties p = new Properties();
        FileInputStream in = null;
        try {
            if (config.exists()) {
                in = new FileInputStream(config);
                p.load(in);
            }
        } catch (Throwable ignore) {
        } finally {
            try {
                if (in != null) in.close();
            } catch (Throwable ignore) {
            }
        }

        String sec = String.valueOf(toMs / 1000.0);
        if (key != null && !key.isEmpty()) {
            p.setProperty("intro." + key, sec);
        } else {
            p.setProperty("intro", sec);
        }

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(config);
            p.store(out, "jcy_skip");
            out.flush();
            lastMod = -2L;              // 强制下次 reload
            MainHook.log("已记住片头 = " + sec + "s (key=" + key + ")");
        } catch (Throwable t) {
            MainHook.log("保存失败: " + t);
        } finally {
            try {
                if (out != null) out.close();
            } catch (Throwable ignore) {
            }
        }
    }

    // ------------------------------------------------------------------ 视频指纹
    /**
     * 把视频地址归一化成「一部剧」的 key：
     * 去掉 query、去掉最后一段路径，剩下的 hash 作为同剧标识。
     */
    static String keyOf(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty() || "null".equals(s)) return "";
        int q = s.indexOf('?');
        if (q > 0) s = s.substring(0, q);
        int slash = s.lastIndexOf('/');
        if (slash > 8) s = s.substring(0, slash);
        return "k" + Integer.toHexString(s.hashCode());
    }
}
