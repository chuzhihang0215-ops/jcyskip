package com.qingshui.jcyskip;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 囧次元 (com.tudou.tool) 自动跳过片头/片尾。
 *
 * 目标 App 结构（实测）：Flutter(Dart AOT) + 阿里云播放器 SaaS 5.4.5.0 + 加固壳。
 * 业务 dex 被壳加密，静态搜不到任何 alivc/aliyun 类，因此不能在 handleLoadPackage
 * 阶段直接 hook，必须等壳把 dex 解出来后再重试。
 *
 * 播放器 Java 层类名来自 libsaasCorePlayer.so 的 JNI 注册字符串（可复核）：
 *   com/aliyun/player/nativeclass/NativePlayerBase     <- nSeekTo / nGetCurrentPosition
 *   com/aliyun/player/nativeclass/JniSaasPlayer
 *   com/aliyun/player/nativeclass/JniUrlPlayer
 *   com/aliyun/player/AliPlayerGlobalSettings
 */
public class MainHook implements IXposedHookLoadPackage {

    /** 目标包名 */
    public static final String PKG = "com.tudou.tool";

    /** 播放器实现类候选，谁先出现就 hook 谁 */
    private static final String[] PLAYER_CLASSES = {
            "com.aliyun.player.nativeclass.NativePlayerBase",
            "com.aliyun.player.nativeclass.JniSaasPlayer",
            "com.aliyun.player.nativeclass.JniUrlPlayer",
            "com.aliyun.player.nativeclass.JniListPlayerBase",
            "com.aliyun.player.nativeclass.JniUrlListPlayer",
    };

    private static final Set<String> HOOKED = new HashSet<String>();
    private static boolean ready = false;

    public static void log(String msg) {
        XposedBridge.log("[JcySkip] " + msg);
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName)) return;
        log("attach " + lp.packageName + " / " + lp.processName);

        // dex 还没解密时 findClass 一定失败，先挂 Application.onCreate，起来后再轮询重试
        try {
            XposedHelpers.findAndHookMethod(Application.class, "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            Context ctx = (Context) param.thisObject;
                            try {
                                SkipStore.init(ctx);
                            } catch (Throwable t) {
                                log("SkipStore.init failed: " + t);
                            }
                            startRetry(lp.classLoader);
                        }
                    });
        } catch (Throwable t) {
            log("hook Application.onCreate failed: " + t);
            startRetry(lp.classLoader);
        }
    }

    private static void startRetry(final ClassLoader cl) {
        final Handler h = new Handler(Looper.getMainLooper());
        final int[] tries = {0};
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                tries[0]++;
                boolean ok = install(cl);
                if (!ok && tries[0] < 120) {
                    h.postDelayed(this, 1000);
                }
            }
        }, 600);
    }

    private static synchronized boolean install(ClassLoader cl) {
        boolean any = false;
        for (String name : PLAYER_CLASSES) {
            if (HOOKED.contains(name)) {
                any = true;
                continue;
            }
            try {
                Class<?> c = XposedHelpers.findClass(name, cl);
                hookOne(c);
                HOOKED.add(name);
                any = true;
                log("hooked " + name);
            } catch (Throwable ignore) {
                // 类还没被壳解密出来，下一秒再来
            }
        }
        if (any && !ready) {
            ready = true;
            log("player hooks ready");
        }
        return any;
    }

    private static void hookOne(final Class<?> c) {
        // 1) 构造函数：拿到播放器实例
        try {
            XposedBridge.hookAllConstructors(c, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    PlayerWatcher.attach(param.thisObject);
                }
            });
        } catch (Throwable t) {
            log("ctor hook failed " + c.getSimpleName() + ": " + t);
        }

        // 2) seekTo：学习用户手动拖过了哪一段
        try {
            XposedBridge.hookAllMethods(c, "seekTo", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (PlayerWatcher.isSelfSeek()) return;          // 别把自己的 seek 当成用户行为
                    if (param.args == null || param.args.length == 0) return;
                    if (!(param.args[0] instanceof Long)) return;
                    PlayerWatcher.onUserSeek(param.thisObject, (Long) param.args[0]);
                }
            });
        } catch (Throwable t) {
            log("seekTo hook failed: " + t);
        }

        // 3) 换集 / 换源：重置状态，并记下当前视频地址用于按剧存储
        for (String m : new String[]{"setDataSource", "nSetDataSource"}) {
            try {
                XposedBridge.hookAllMethods(c, m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        String key = "";
                        if (param.args != null && param.args.length > 0 && param.args[0] != null) {
                            Object a = param.args[0];
                            try {
                                key = String.valueOf(XposedHelpers.callMethod(a, "getUri"));
                            } catch (Throwable ignore) {
                                key = String.valueOf(a);
                            }
                        }
                        PlayerWatcher.onSourceChanged(param.thisObject, key);
                    }
                });
            } catch (Throwable ignore) {
                // 该方法不存在就跳过
            }
        }
    }
}
