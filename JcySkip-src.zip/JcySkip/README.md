# JcySkip —— 囧次元 自动跳过片头 / 片尾（LSPosed 模块）

对象：`com.tudou.tool`（囧次元 1.5.8.0）

---

## 一、为什么只能这么做（实测证据）

对 APK 做过静态分析，结论如下，这直接决定了模块的形态：

| 事实 | 证据 |
|---|---|
| 是 **Flutter** 应用 | `lib/arm64-v8a/libflutter.so` + `libapp.so`(12MB, Dart AOT)；`assets/flutter_assets/*` |
| 播放器是 **阿里云播放器 SaaS 5.4.5.0** | `libsaasCorePlayer.so` / `libcore.so` / `libalivcffmpeg.so`；`.rodata` 里有版本串 `5.4.5.0` 紧邻 `NativePlayerBase` |
| Java 层类名是 `com.aliyun.player.*` | `libsaasCorePlayer.so` 的 JNI 注册串：`com/aliyun/player/nativeclass/NativePlayerBase`、`JniSaasPlayer`、`JniUrlPlayer`、`com/aliyun/player/AliPlayerGlobalSettings`、`com/aliyun/player/source/UrlSource` |
| 播放/跳转的 native 入口 | `_ZN10NativeBase11java_SeekToEP7_JNIEnvP8_jobjectxi`、`java_GetCurrentPosition`、`nSeekTo`、`nGetCurrentPosition` |
| **业务 dex 被加固加密** | 全 APK 只有 451 个类（427 androidx + 24 com.*），搜 `alivc/aliyun/player` 命中 0；壳为 `libSecShell.so`、`libyj-v3-pt-326.so`(网易易盾)、`libzeus_direct_dex.so` |
| App 自身**没有**「跳过片头」功能 | 在 `libapp.so` 里按 UTF-16LE 搜「片头」「片尾」「跳过」全部 0 命中（同法搜「播放错误，可点击播放」能命中，说明搜索方法没问题）|
| Dart 侧播放器插件 | `package:aliyun_player/src/aliyun_player_controller.dart`、`seekTo`、`seekToRelativePosition` |

三点直接推论：

1. **改 APK 不可行**：dex 加密 + 壳会校验完整性/签名，重打包必挂。
2. **Java 静态 hook 不可行**：hook 时机拿不到类（还没解密），所以模块里用「Application.onCreate 后每秒重试 findClass，最多 120 秒」。
3. **Dart AOT 不可 hook**：所以不去改 Flutter 逻辑，而是直接操作它下面的阿里云播放器 Java 对象。

---

## 二、结构

```
JcySkip/
├── settings.gradle / build.gradle / gradle.properties
├── app/build.gradle
├── app/src/main/AndroidManifest.xml     # xposedmodule / xposedscope
├── app/src/main/assets/xposed_init      # 入口类
├── app/src/main/res/values/arrays.xml   # 作用域 com.tudou.tool
└── app/src/main/java/com/qingshui/jcyskip/
    ├── MainHook.java        # 装 hook：构造 / seekTo / setDataSource
    ├── PlayerWatcher.java   # 0.7s 轮询进度，命中规则就 seek
    └── SkipStore.java       # 规则读写 + 学习逻辑
```

## 三、编译

本机没有 JDK / Android SDK，模块需要你自己打一次包，两种方式：

**A. Android Studio**：打开 `JcySkip/` 目录 → Build → Build APK(s)。

**B. 手机上没有电脑**：把这个目录推到 GitHub，仓库自带 `.github/workflows/build.yml`，
推上去后 Actions 会自动产出 APK，在 Artifacts 里下载 `JcySkip-apk`。

APK 用 debug 签名即可，LSPosed 不校验模块签名。

## 四、安装

1. 装 APK；
2. LSPosed → 模块 → 勾选「囧次元跳片头」→ **作用域只要勾 `囧次元`**；
3. 强行停止囧次元，重新打开。

## 五、怎么用

### 方式 1：让它自己学（推荐）

第一次看某部番的第 1 集：

1. 片头放到你想跳过的位置，**手动把进度条拖过片头**；
2. 再拖一次同样的位置（两次落点相差 10 秒内即可）；
3. 模块写入规则，之后**这部剧**每集播到该位置自动跳。

日志里会看到：

```
[JcySkip] player instance = com.aliyun.player.nativeclass.JniSaasPlayer
[JcySkip] source changed -> key=k1a2b3c4d uri=https://.../xxx.m3u8
[JcySkip] 学习候选: 从 12000ms 跳到 92000ms（再跳一次同样位置即生效）
[JcySkip] 已记住片头 = 92.0s (key=k1a2b3c4d)
[JcySkip] 跳过片头: 91800ms -> 92200ms
```

换一部剧时重新拖两次，会生成新的 `intro.<key>`，互不干扰。

### 方式 2：直接填数字

模块第一次运行会在下面生成配置文件：

```
/sdcard/Android/data/com.tudou.tool/files/jcy_skip.txt
```

```properties
enabled=1      # 总开关
intro=92       # 片头结束位置（秒），所有没单独配的剧都用这个
outro=90       # 片尾提前 90 秒跳到结尾（0 = 关闭）
auto_learn=1   # 自动学习开关
```

改完保存，播放中 1 秒内生效，不用重启 App。

## 六、看日志

```sh
adb logcat -s LSPosed-Bridge
```

或在 LSPosed → 日志里搜 `JcySkip`。

如果一直只有 `attach ...` 而没有 `hooked ...`，说明类名不对（SDK 版本不同）——
把日志发我，我按实际类名改。

## 七、已知风险（务必看）

1. **加固壳检测**：这是爱加密(SecShell) + 网易易盾 + Zeus 三重壳，会做 Xposed/LSPosed 环境检测，
   可能出现「模块生效但 App 闪退」或「App 直接提示环境异常」。对策：
   - LSPosed 里对囧次元开启 **隐藏模块 / 随机包名**；
   - 用 **Shamiko**（Magisk 白名单模式）配合；
   - 只勾选囧次元一个作用域，别把 LSPosed 的「系统框架」勾上。
2. **播放器版本变了就要改类名**：本模块按 5.4.5.0 的 `com.aliyun.player.*` 写的，
   App 升级后若换了 SDK，需要重跑一遍 `.so` 里的 JNI 字符串确认。
3. **片尾跳过的语义**：是「跳到结尾触发播放结束」，依赖 App 自己有自动下一集。
   没有该行为时表现为「直接停在最后一帧」。
4. **本模块未在真机实测**（我这边没有 root/adb 可以 attach 验证）。
   逻辑按 SDK 公开 API + `.so` 里的 JNI 证据写死，首次运行请先看日志确认 `hooked ...` 出现。
